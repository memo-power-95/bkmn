@echo off
setlocal
title Limpiar fotos LOG - Linea 2 TLA
REM Guillermo Carrillo - menu para instalar y manejar la limpieza de fotos .bmp
REM Debe estar en la misma carpeta que Limpiar_Fotos_LOG.ps1

set "ORIGEN=%~dp0Limpiar_Fotos_LOG.ps1"
set "DESTINO=C:\Scripts\Limpiar_Fotos_LOG.ps1"
set "BITACORA=C:\Scripts\Limpiar_Fotos_LOG.txt"
set "TAREA=Limpiar fotos LOG"
set "PS=powershell.exe -NoProfile -ExecutionPolicy Bypass -File"

REM ---- Revisar que este como administrador ----
net session >nul 2>&1
if errorlevel 1 (
  echo.
  echo  Hay que abrirlo como ADMINISTRADOR:
  echo  clic derecho en Limpiar_Fotos_LOG.bat ^> Ejecutar como administrador
  echo.
  pause
  exit /b 1
)

:MENU
cls
echo ==========================================================
echo   LIMPIAR FOTOS .BMP DE D:\EVMS\TP\LOG
echo ==========================================================
echo   1. PROBAR: contar cuantas fotos se borrarian (no borra)
echo   2. INSTALAR: copiar el script y programarlo cada 3 horas
echo   3. CORRER AHORA una limpieza
echo   4. VER la bitacora
echo   5. VER si la tarea esta programada
echo   6. QUITAR la tarea programada
echo   7. Salir
echo ==========================================================
set "OP="
set /p "OP=Elige una opcion (1-7): "
if "%OP%"=="1" goto PROBAR
if "%OP%"=="2" goto INSTALAR
if "%OP%"=="3" goto CORRER
if "%OP%"=="4" goto BITACORA
if "%OP%"=="5" goto ESTADO
if "%OP%"=="6" goto QUITAR
if "%OP%"=="7" exit /b 0
goto MENU

:COPIAR
if not exist "C:\Scripts" mkdir "C:\Scripts"
if exist "%ORIGEN%" (
  copy /Y "%ORIGEN%" "%DESTINO%" >nul
)
if not exist "%DESTINO%" (
  echo.
  echo  No encuentro Limpiar_Fotos_LOG.ps1 junto a este .bat ni en C:\Scripts.
  echo  Pon los dos archivos en la misma carpeta y vuelve a intentar.
  echo.
  pause
  goto MENU
)
exit /b 0

:PROBAR
call :COPIAR
%PS% "%DESTINO%" -Prueba
echo.
pause
goto MENU

:INSTALAR
call :COPIAR
schtasks /Create /TN "%TAREA%" /TR "powershell.exe -NoProfile -ExecutionPolicy Bypass -File %DESTINO%" /SC HOURLY /MO 3 /RU SYSTEM /RL HIGHEST /F
echo.
echo  Listo. Corre cada 3 horas como SYSTEM, aunque nadie inicie sesion.
echo.
pause
goto MENU

:CORRER
call :COPIAR
echo  Borrando fotos con mas horas de las configuradas...
%PS% "%DESTINO%"
echo.
pause
goto MENU

:BITACORA
if exist "%BITACORA%" (
  start notepad "%BITACORA%"
) else (
  echo.
  echo  Todavia no hay bitacora. Se crea en la primera corrida.
  echo.
  pause
)
goto MENU

:ESTADO
schtasks /Query /TN "%TAREA%" /V /FO LIST | findstr /I "TaskName Nombre Next Proxima Last Ultim Status Estado"
echo.
pause
goto MENU

:QUITAR
schtasks /Delete /TN "%TAREA%" /F
echo.
pause
goto MENU
